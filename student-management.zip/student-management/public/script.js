// ==========================================
// LOAD STUDENTS
// ==========================================

function loadStudents() {

    fetch('/students')

        .then(response => {

            if (!response.ok) {
                throw new Error('Failed to load students');
            }

            return response.json();

        })

        .then(students => {

            const table =
                document.getElementById('studentTable');

            table.innerHTML = '';


            students.forEach(student => {

                const row =
                    document.createElement('tr');


                row.innerHTML = `

                    <td>
                        ${student.student_id}
                    </td>

                    <td>
                        ${student.name}
                    </td>

                    <td>
                        ${student.department}
                    </td>

                    <td>
                        ${student.phone || ''}
                    </td>

                    <td>
                        ${student.cgpa}
                    </td>

                    <td>

                        <button
                            onclick="editStudent(
                                ${student.student_id},
                                '${escapeQuotes(student.name)}',
                                '${escapeQuotes(student.department)}',
                                '${escapeQuotes(student.phone || '')}',
                                ${student.cgpa}
                            )"
                        >
                            Edit
                        </button>

                        <button
                            onclick="deleteStudent(
                                ${student.student_id}
                            )"
                        >
                            Delete
                        </button>

                    </td>

                `;


                table.appendChild(row);

            });

        })

        .catch(error => {

            console.error(
                'Error loading students:',
                error
            );

        });

}


// ==========================================
// ESCAPE QUOTES
// ==========================================

function escapeQuotes(value) {

    return String(value)
        .replace(/\\/g, '\\\\')
        .replace(/'/g, "\\'");

}


// ==========================================
// ADD STUDENT
// ==========================================

document
    .getElementById('studentForm')
    .addEventListener('submit', function(event) {

        event.preventDefault();


        const student = {

            student_id:
                document.getElementById('student_id').value,

            name:
                document.getElementById('name').value,

            department:
                document.getElementById('department').value,

            phone:
                document.getElementById('phone').value,

            cgpa:
                document.getElementById('cgpa').value

        };


        fetch('/students', {

            method: 'POST',

            headers: {

                'Content-Type':
                    'application/json'

            },

            body:
                JSON.stringify(student)

        })

        .then(response => response.json())

        .then(data => {

            if (data.error) {

                alert(data.error);

                return;

            }


            alert(data.message);


            document
                .getElementById('studentForm')
                .reset();


            loadStudents();

            loadLogs();

        })

        .catch(error => {

            console.error(
                'Add error:',
                error
            );

            alert('Something went wrong!');

        });

    });


// ==========================================
// EDIT STUDENT
// ==========================================

function editStudent(
    id,
    name,
    department,
    phone,
    cgpa
) {

    document.getElementById('student_id').value =
        id;

    document.getElementById('name').value =
        name;

    document.getElementById('department').value =
        department;

    document.getElementById('phone').value =
        phone;

    document.getElementById('cgpa').value =
        cgpa;

}


// ==========================================
// UPDATE STUDENT
// ==========================================

document
    .getElementById('updateButton')
    .addEventListener('click', function() {

        const studentId =
            document.getElementById('student_id').value;


        if (!studentId) {

            alert('Please enter Student ID.');

            return;

        }


        const updatedStudent = {

            name:
                document.getElementById('name').value,

            department:
                document.getElementById('department').value,

            phone:
                document.getElementById('phone').value,

            cgpa:
                document.getElementById('cgpa').value

        };


        fetch(`/students/${studentId}`, {

            method: 'PUT',

            headers: {

                'Content-Type':
                    'application/json'

            },

            body:
                JSON.stringify(updatedStudent)

        })

        .then(response => response.json())

        .then(data => {

            if (data.error) {

                alert(data.error);

                return;

            }


            alert(data.message);


            document
                .getElementById('studentForm')
                .reset();


            loadStudents();

            loadLogs();

        })

        .catch(error => {

            console.error(
                'Update error:',
                error
            );

            alert('Something went wrong!');

        });

    });


// ==========================================
// DELETE STUDENT
// ==========================================

function deleteStudent(id) {

    const confirmDelete =
        confirm(
            'Are you sure you want to delete this student?'
        );


    if (!confirmDelete) {

        return;

    }


    fetch(`/students/${id}`, {

        method: 'DELETE'

    })

    .then(response => response.json())

    .then(data => {

        if (data.error) {

            alert(data.error);

            return;

        }


        alert(data.message);


        loadStudents();

        loadLogs();

    })

    .catch(error => {

        console.error(
            'Delete error:',
            error
        );

        alert('Something went wrong!');

    });

}


// ==========================================
// CANCEL / CLEAR FORM
// ==========================================

document
    .getElementById('cancelButton')
    .addEventListener('click', function() {

        document
            .getElementById('studentForm')
            .reset();

    });


// ==========================================
// LOAD TRIGGER LOGS
// ==========================================

function loadLogs() {

    fetch('/logs')

        .then(response => {

            if (!response.ok) {
                throw new Error(
                    'Failed to load logs'
                );
            }

            return response.json();

        })

        .then(logs => {

            const table =
                document.getElementById('logTable');

            table.innerHTML = '';


            logs.forEach(log => {

                const row =
                    document.createElement('tr');


                row.innerHTML = `

                    <td>
                        ${log.log_id}
                    </td>

                    <td>
                        ${log.student_id}
                    </td>

                    <td>
                        ${log.action}
                    </td>

                    <td>
                        ${log.action_time}
                    </td>

                `;


                table.appendChild(row);

            });

        })

        .catch(error => {

            console.error(
                'Error loading logs:',
                error
            );

        });

}


// ==========================================
// REFRESH LOGS BUTTON
// ==========================================

document
    .getElementById('refreshLogsButton')
    .addEventListener('click', function() {

        loadLogs();

    });


// ==========================================
// INITIAL LOAD
// ==========================================

loadStudents();

loadLogs();