const express = require('express');
const mysql = require('mysql2');

const app = express();
const PORT = 3000;

// ===============================
// MySQL Connection
// ===============================

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'student_management'
});

// ===============================
// Check MySQL Connection
// ===============================

connection.connect((err) => {
    if (err) {
        console.error('MySQL connection failed:', err.message);
        return;
    }

    console.log('MySQL connected successfully!');
});

// ===============================
// Middleware
// ===============================

app.use(express.json());
app.use(express.static('public'));

// ===============================
// GET ALL STUDENTS
// ===============================

app.get('/students', (req, res) => {

    const sql = 'SELECT * FROM students';

    connection.query(sql, (err, results) => {

        if (err) {
            console.error('Database error:', err.message);

            return res.status(500).json({
                error: 'Database error'
            });
        }

        res.json(results);
    });
});

// ===============================
// ADD STUDENT
// ===============================

app.post('/students', (req, res) => {

    const {
        student_id,
        name,
        department,
        phone,
        cgpa
    } = req.body;

    const sql = `
        INSERT INTO students
        (student_id, name, department, phone, cgpa)
        VALUES (?, ?, ?, ?, ?)
    `;

    connection.query(
        sql,
        [student_id, name, department, phone, cgpa],
        (err, result) => {

            if (err) {
                console.error('Insert error:', err.message);

                return res.status(500).json({
                    error: err.message
                });
            }

            res.json({
                message: 'Student added successfully!'
            });
        }
    );
});

// ===============================
// UPDATE STUDENT
// ===============================

app.put('/students/:id', (req, res) => {

    const studentId = req.params.id;

    const {
        name,
        department,
        phone,
        cgpa
    } = req.body;

    const sql = `
        UPDATE students
        SET
            name = ?,
            department = ?,
            phone = ?,
            cgpa = ?
        WHERE student_id = ?
    `;

    connection.query(
        sql,
        [name, department, phone, cgpa, studentId],
        (err, result) => {

            if (err) {
                console.error('Update error:', err.message);

                return res.status(500).json({
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {

                return res.status(404).json({
                    error: 'Student not found'
                });
            }

            res.json({
                message: 'Student updated successfully!'
            });
        }
    );
});

// ===============================
// DELETE STUDENT
// ===============================

app.delete('/students/:id', (req, res) => {

    const studentId = req.params.id;

    const sql = `
        DELETE FROM students
        WHERE student_id = ?
    `;

    connection.query(
        sql,
        [studentId],
        (err, result) => {

            if (err) {
                console.error('Delete error:', err.message);

                return res.status(500).json({
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {

                return res.status(404).json({
                    error: 'Student not found'
                });
            }

            res.json({
                message: 'Student deleted successfully!'
            });
        }
    );
});

// ===============================
// GET TRIGGER LOGS
// ===============================

app.get('/logs', (req, res) => {

    const sql = `
        SELECT
            log_id,
            student_id,
            action,
            action_time
        FROM student_logs
        ORDER BY log_id DESC
    `;

    connection.query(sql, (err, results) => {

        if (err) {
            console.error('Log database error:', err.message);

            return res.status(500).json({
                error: 'Failed to load trigger logs'
            });
        }

        res.json(results);
    });
});

// ===============================
// START SERVER
// ===============================

app.listen(PORT, () => {

    console.log(
        `Server running at http://localhost:${PORT}`
    );

});